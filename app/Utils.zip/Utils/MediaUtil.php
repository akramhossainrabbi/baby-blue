<?php

namespace App\Utils;

use App\TaxRate;
use App\Media;

class MeidaUtil extends Util
{

    /**
     * Updates tax amount of a tax group
     *
     * @param int $group_tax_id
     *
     * @return void
     */

}
